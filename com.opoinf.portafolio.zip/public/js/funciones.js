window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date())

gtag('config', 'G-HP44YDVHH1')
$(document).ready(function() {
    // Habilitar todos los popovers
    $('[data-toggle="popover"]').popover({
        html : true
    })

    // Menu flotante
    var windowHeight1 = $(window).scrollTop();
    var contenido21 = $("#mostrar-opcionesflotantes").offset();

    contenido21 = contenido21.top;

    if(windowHeight1 >= contenido21  ){

        //$('#OpcionesFlotantes').fadeIn("slow");
        jQuery("#OpcionesFlotantes").addClass('fade-in').removeClass('fade-out');

    }
    $(window).scroll(function(){


            var windowHeight = $(window).scrollTop();
            var contenido2 = $("#mostrar-opcionesflotantes").offset();

            contenido2 = contenido2.top;

            if(windowHeight >= contenido2  ){

                //$('#OpcionesFlotantes').fadeIn("slow");
                jQuery("#OpcionesFlotantes").addClass('fade-in').removeClass('fade-out');

            }else{

                //$('#OpcionesFlotantes').fadeOut("slow");
                jQuery("#OpcionesFlotantes").removeClass('fade-in').addClass('fade-out');

            }


    });
    

});
function irProyectos() {
    document.getElementById("proyectos").scrollIntoView({block: "start", behavior: "smooth"});    
}
function irConocimientos() {
    document.getElementById("conocimientos").scrollIntoView({block: "start", behavior: "smooth"});    
}
function irPerfilLaboral() {
    document.getElementById("perfilLaboral").scrollIntoView({block: "start", behavior: "smooth"});    
}
function irResumenHistorico() {
    document.getElementById("resumenHistorico").scrollIntoView({block: "start", behavior: "smooth"});    
}
function irHistoria() {
    document.getElementById("historia").scrollIntoView({block: "start", behavior: "smooth"});    
}


